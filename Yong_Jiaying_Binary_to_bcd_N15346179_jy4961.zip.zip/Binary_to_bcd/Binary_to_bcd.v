module binary_to_bcd_converter (
    input      [4:0] binary_input, // 5-bit binary input (0-31)
    output reg [7:0] bcd_output    // 8-bit BCD output {tens, ones}
);

    // This combinational block is sensitive to any changes in binary_input.
    // The `reg` type is required for outputs assigned within an `always` block.
    always @(*) begin
        // Use a case statement to map each binary input to its BCD equivalent.
        // The concatenation {tens_digit, ones_digit} makes the code readable.
        case (binary_input)
            // Values 0-9
            5'd0:  bcd_output = {4'h0, 4'h0}; // 00
            5'd1:  bcd_output = {4'h0, 4'h1}; // 01
            5'd2:  bcd_output = {4'h0, 4'h2}; // 02
            5'd3:  bcd_output = {4'h0, 4'h3}; // 03
            5'd4:  bcd_output = {4'h0, 4'h4}; // 04
            5'd5:  bcd_output = {4'h0, 4'h5}; // 05
            5'd6:  bcd_output = {4'h0, 4'h6}; // 06
            5'd7:  bcd_output = {4'h0, 4'h7}; // 07
            5'd8:  bcd_output = {4'h0, 4'h8}; // 08
            5'd9:  bcd_output = {4'h0, 4'h9}; // 09

            // Values 10-19
            5'd10: bcd_output = {4'h1, 4'h0}; // 10
            5'd11: bcd_output = {4'h1, 4'h1}; // 11
            5'd12: bcd_output = {4'h1, 4'h2}; // 12
            5'd13: bcd_output = {4'h1, 4'h3}; // 13
            5'd14: bcd_output = {4'h1, 4'h4}; // 14
            5'd15: bcd_output = {4'h1, 4'h5}; // 15
            5'd16: bcd_output = {4'h1, 4'h6}; // 16
            5'd17: bcd_output = {4'h1, 4'h7}; // 17
            5'd18: bcd_output = {4'h1, 4'h8}; // 18
            5'd19: bcd_output = {4'h1, 4'h9}; // 19

            // Values 20-29
            5'd20: bcd_output = {4'h2, 4'h0}; // 20
            5'd21: bcd_output = {4'h2, 4'h1}; // 21
            5'd22: bcd_output = {4'h2, 4'h2}; // 22
            5'd23: bcd_output = {4'h2, 4'h3}; // 23
            5'd24: bcd_output = {4'h2, 4'h4}; // 24
            5'd25: bcd_output = {4'h2, 4'h5}; // 25
            5'd26: bcd_output = {4'h2, 4'h6}; // 26
            5'd27: bcd_output = {4'h2, 4'h7}; // 27
            5'd28: bcd_output = {4'h2, 4'h8}; // 28
            5'd29: bcd_output = {4'h2, 4'h9}; // 29

            // Values 30-31
            5'd30: bcd_output = {4'h3, 4'h0}; // 30
            5'd31: bcd_output = {4'h3, 4'h1}; // 31

            // A default case prevents unintentional latch inference by the
            // synthesis tool. We set the output to 'x' (don't care) as
            // these states are unreachable for a 5-bit input.
            default: bcd_output = 8'hXX;
        endcase
    end

endmodule