module alu_8bit (
  input  [7:0] a,
  input  [7:0] b,
  input        cin,
  input  [3:0] alu_sel,
  output reg [7:0] alu_out,
  output       alu_cout
);

  // Carry-out logic derived from a 9-bit addition, as per constraints.
  // This is independent of the alu_sel operation.
  wire [8:0] sum9 = {1'b0, a} + {1'b0, b};
  assign alu_cout = sum9[8];

  // Combinational logic block for ALU operations
  always @(*) begin
    case (alu_sel)
      4'b0000: alu_out = a + b;
      4'b0001: alu_out = a - b;
      4'b0010: alu_out = a * b;          // Verilog truncates the 16-bit result to the low 8 bits
      4'b0011: alu_out = a / b;          // Assumes b is not zero
      4'b0100: alu_out = a << 1;
      4'b0101: alu_out = a >> 1;
      4'b0110: alu_out = {a[6:0], a[7]}; // Rotate left by 1
      4'b0111: alu_out = {a[0], a[7:1]}; // Rotate right by 1
      4'b1000: alu_out = a & b;
      4'b1001: alu_out = a | b;
      4'b1010: alu_out = a ^ b;
      4'b1011: alu_out = ~(a | b);       // NOR
      4'b1100: alu_out = ~(a & b);       // NAND
      4'b1101: alu_out = ~(a ^ b);       // XNOR
      4'b1110: alu_out = (a >  b) ? 8'd1 : 8'd0;
      4'b1111: alu_out = (a == b) ? 8'd1 : 8'd0;
      default: alu_out = a + b;
    endcase
  end

endmodule