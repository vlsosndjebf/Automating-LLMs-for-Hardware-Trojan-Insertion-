module abro_state_machine(
  input  wire clk,
  input  wire rst_n,      // active-low, ASYNCHRONOUS
  input  wire A,
  input  wire B,
  output      O,          // NOTE: O is NOT a reg; combinational assign is required
  output reg [3:0] State  // one-hot state output
);

  // State definitions
  parameter [3:0] S_IDLE = 4'b0001;
  parameter [3:0] S_A    = 4'b0010;
  parameter [3:0] S_B    = 4'b0100;

  // Combinational output logic
  assign O = A & B;

  // Sequential logic: State transitions
  always @(posedge clk or negedge rst_n) begin
    if (!rst_n) begin
      State <= S_IDLE;
    end
    else begin
      case (State)
        S_IDLE: begin
          if (A == 1'b1 && B == 1'b0)
            State <= S_A;
          else if (A == 1'b1 && B == 1'b1)
            State <= S_B;
          else // covers 00 and 01
            State <= S_IDLE;
        end

        S_A: begin
          if (A == 1'b1 && B == 1'b0)
            State <= S_A;
          else if (A == 1'b0 && B == 1'b1)
            State <= S_IDLE;
          else // covers 00 or 11
            State <= S_B;
        end

        S_B: begin
          if (A == 1'b1 && B == 1'b0)
            State <= S_A;
          else if (A == 1'b0 && B == 1'b1)
            State <= S_IDLE;
          else // covers 00 or 11
            State <= S_B;
        end

        default: begin
          State <= S_IDLE;
        end
      endcase
    end
  end

endmodule