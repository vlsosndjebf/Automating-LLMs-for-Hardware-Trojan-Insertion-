module dice_roller(
  input  wire       clk,
  input  wire       rst_n,          // active-low, synchronous
  input  wire [1:0] die_select,     // 00=4-sided, 01=6-sided, 10=8-sided, 11=20-sided
  input  wire       roll,           // roll request
  output reg  [7:0] rolled_number   // 1..N (N in {4,6,8,20}); holds last result otherwise
);

  // Internal state registers
  reg [7:0] lfsr;   // 8-bit Linear Feedback Shift Register
  reg       roll_d; // One-cycle delay of 'roll' for edge detection

  // Internal wire for the number of sides, derived from die_select
  reg [7:0] num_sides;

  // Combinational logic to decode die_select into the number of sides (N)
  // This uses a case statement to map the 2-bit input to the correct value.
  always @(die_select) begin
    case (die_select)
      2'b00:   num_sides = 4;
      2'b01:   num_sides = 6;
      2'b10:   num_sides = 8;
      2'b11:   num_sides = 20;
      default: num_sides = 20; // Default case for safety
    endcase
  end

  // Sequential logic block for all stateful elements
  always @(posedge clk) begin
    if (!rst_n) begin
      // Synchronous, active-low reset condition
      lfsr          <= 8'hA5; // Seed LFSR with a non-zero value
      roll_d        <= 1'b0;
      rolled_number <= 8'd0;
    end else begin
      // LFSR advances every clock cycle.
      // The new bit is calculated from taps at x^8+x^6+x^5+x^4+1, which corresponds to
      // an XOR of bits 7, 5, 4, and 3. The register is left-shifted.
      lfsr <= {lfsr[6:0], lfsr[7] ^ lfsr[5] ^ lfsr[4] ^ lfsr[3]};

      // Store the current 'roll' value for edge detection on the next cycle
      roll_d <= roll;

      // Detect the rising edge of 'roll' (i.e., roll is high now but was low previously)
      if (roll && !roll_d) begin
        // On a roll request, map the current LFSR value to the range 1..N
        // using the modulo operator and add 1.
        rolled_number <= (lfsr % num_sides) + 1;
      end
      // If there is no rising edge on 'roll', 'rolled_number' implicitly holds
      // its previous value, as required.
    end
  end

endmodule