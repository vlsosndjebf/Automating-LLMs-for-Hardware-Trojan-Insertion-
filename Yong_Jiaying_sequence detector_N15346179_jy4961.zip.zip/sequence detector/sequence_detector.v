module sequence_detector(
  input  wire       clk,
  input  wire       reset_n,     // active-low, synchronous
  input  wire [2:0] data,
  output reg        sequence_found
);

  // FSM State Encoding: S0=idle, S1=P0, S2=P0-P1, ..., S7=P0-P6
  localparam [3:0] S0 = 4'd0;
  localparam [3:0] S1 = 4'd1;
  localparam [3:0] S2 = 4'd2;
  localparam [3:0] S3 = 4'd3;
  localparam [3:0] S4 = 4'd4;
  localparam [3:0] S5 = 4'd5;
  localparam [3:0] S6 = 4'd6;
  localparam [3:0] S7 = 4'd7;
  localparam [3:0] S8 = 4'd8; // Unused but required by spec

  // Sequence pattern symbols
  localparam [2:0] P0 = 3'b001;
  localparam [2:0] P1 = 3'b101;
  localparam [2:0] P2 = 3'b110;
  localparam [2:0] P3 = 3'b000;
  localparam [2:0] P4 = 3'b110;
  localparam [2:0] P5 = 3'b110;
  localparam [2:0] P6 = 3'b011;
  localparam [2:0] P7 = 3'b101;

  // State registers
  reg [3:0] state, next_state;

  // Sequential Block: State register with synchronous active-low reset
  always @(posedge clk) begin
    if (!reset_n) begin
      state <= S0;
    end else begin
      state <= next_state;
    end
  end

  // Combinational Block: Next state logic and Mealy output logic
  always @* begin
    // Default assignments to prevent latches
    next_state = S0;
    sequence_found = 1'b0;

    case (state)
      S0: begin
        if (data == P0)
          next_state = S1;
        // else next_state = S0 (covered by default)
      end
      S1: begin
        if (data == P1)
          next_state = S2;
        else if (data == P0)
          next_state = S1;
        // else next_state = S0 (covered by default)
      end
      S2: begin
        if (data == P2)
          next_state = S3;
        else if (data == P0)
          next_state = S1;
        // else next_state = S0 (covered by default)
      end
      S3: begin
        if (data == P3)
          next_state = S4;
        else if (data == P0)
          next_state = S1;
        // else next_state = S0 (covered by default)
      end
      S4: begin
        if (data == P4)
          next_state = S5;
        else if (data == P0)
          next_state = S1;
        // else next_state = S0 (covered by default)
      end
      S5: begin
        if (data == P5)
          next_state = S6;
        else if (data == P0)
          next_state = S1;
        // else next_state = S0 (covered by default)
      end
      S6: begin
        if (data == P6)
          next_state = S7;
        else if (data == P0)
          next_state = S1;
        // else next_state = S0 (covered by default)
      end
      S7: begin
        // Mealy output: depends on current state (S7) and current input (data)
        if (data == P7) begin
          sequence_found = 1'b1;
          // After full match, check for overlap. Since P7 != P0,
          // the sequence does not start over, so we return to S0.
          next_state = S0;
        end else if (data == P0) begin
          // Mismatch, but the new input starts a new sequence
          next_state = S1;
        end
        // else next_state = S0 (covered by default)
      end
      default: begin // For S8 or any other invalid state
        next_state = S0;
      end
    endcase
  end

endmodule